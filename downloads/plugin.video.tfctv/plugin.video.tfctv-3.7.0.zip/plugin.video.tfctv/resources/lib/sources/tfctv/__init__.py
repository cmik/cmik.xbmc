# -*- coding: utf-8 -*-

"""
TFC.tv API Module
"""

from resources.lib.libraries.control import thisPlugin
from .auth import *
from .api import *
from .catalog import *
from .playback import *
from .library import *
from .user import *
from .history import *
from .trakt import *
from .utils import *

__all__ = [
    # Auth
    'login', 'logout', 'isLoggedIn', 'loginToWebsite', 'loginWithFacebook',
    'checkAccountChange', 'enterCredentials', 'checkFacebookToken',
    
    # Catalog
    'getShow', 'getShows', 'getShowWithEpisodes', 'getEpisode',
    'getEpisodesPerPage', 'getCategories', 'getWebsiteHomeSections',
    'getWebsiteSectionContent', 'getHomeCatalog', 'getSettings', 'loadSettings',
    'getItemData', 'checkCatalogUpdates',
    
    # Playback
    'playEpisode', 'getMediaInfo', 'getMediaInfoFromWebsite',
    'getEpisodeFromShow', 'getEpisodeFromLiveStream',
    
    # Library
    'addToLibrary', 'removeFromLibrary', 'showExportedShowsToLibrary',
    'checkLibraryUpdates', 'generateShowNFO', 'generateEpisodeNFO',
    
    # User
    'getUserData', 'getUserInfo', 'getUserName', 'getUserSubscription', 'getUserId',
    'getUserTransactions', 'refreshUserData',
    'refreshUserSubscriptions', 'refreshUserInfo', 'refreshUserContext',
    'getAccount', 'setAccount', 'getFingerprintID', 'getDeviceIP',
    'getCountryCode', 'getGeoLocation', 'refreshGeoLocation', 'generateNewFingerprintID',
    
    # MyList
    'getMyList', 'getMylistShowLastEpisodes', 'addToMyList', 'removeFromMyList',
    
    # Search
    'enterSearch',
    
    # Utils
    'unicodetoascii', 'checkProxy', 'cleanCookies',
    'updateCatalogCache', 'reloadCatalogCache', 'resetCatalogCache', 'catchUpCatalog',
    'removeDuplicates', 'checkIfError',
    
    # Trakt
    'connectTrakt', 'disconnectTrakt', 'getTraktClient',

    # Cookies
    'getFromCookieByName', 'getCookieContent',
    
    # DB Access
    'episodeDB', 'showDB', 'libraryDB', 'castDB',
    
    # Global
    'thisPlugin'
]
