# -*- coding: utf-8 -*-

'''
    Tfc.tv Add-on
    Copyright (C) 2018 cmik

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''


import os,sys,urlparse,urllib,xbmc
from resources import config
from resources.lib.libraries import control
from resources.lib.libraries import cache
from resources.lib.sources import tfctv
from operator import itemgetter

artPath = control.artPath()
addonFanart = control.addonFanart()
logger = control.logger

try: 
    action = dict(urlparse.parse_qsl(sys.argv[2].replace('?','')))['action']
except:
    action = None

sysaddon = sys.argv[0]
thisPlugin = int(sys.argv[1])

class navigator:

    def root(self):
        tfctv.checkAccountChange()
        if control.setting('useProxy') == 'true':
            tfctv.checkProxy()
        
        # if not logged in, ask to log in
        if tfctv.isLoggedIn() == False:
            if control.setting('emailAddress') != '':
                if (control.confirm(control.lang(57007), line1=control.lang(57008) % control.setting('emailAddress'))):
                    (account, logged) = tfctv.checkAccountChange(True)
            else:
                if control.setting('addonNewInstall') == 'true':
                    control.showMessage(control.lang(57016), control.lang(57018))
                    control.setSetting('addonNewInstall', 'false')
                else:
                    control.showNotification(control.lang(57017), control.lang(50002))
        elif control.setting('displayMyList') == 'true':
            self.addDirectoryItem(control.lang(50200), '/', config.MYLIST, control.addonFolderIcon(control.lang(50200)), isFolder=True, **self.formatMenu())
        
        if control.setting('displayWebsiteSections') == 'true':
            self.addDirectoryItem(control.lang(50201), '/', config.CATEGORIES, control.addonFolderIcon(control.lang(50201)), isFolder=True, **self.formatMenu())
        else:
            self.showCategories()
            
        if control.setting('displayWebsiteSections') == 'true':
            control.showNotification(control.lang(57020), control.lang(50008))
            # sections = cache.sCacheFunction(tfctv.getWebsiteHomeSections)
            sections = tfctv.getWebsiteHomeSections()
            for s in sections:
                self.addDirectoryItem(s['name'].title(), str(s['id']), config.SECTIONCONTENT, control.addonFolderIcon(s['name'].title()), isFolder=True, **self.formatMenu())
            
        if control.setting('displayMyAccountMenu') == 'true':    
            self.addDirectoryItem(control.lang(50202), '/', config.MYACCOUNT, control.addonFolderIcon(control.lang(50202)), isFolder=True, **self.formatMenu())
        
        if control.setting('displayTools') == 'true':
            self.addDirectoryItem(control.lang(50203), '/', config.TOOLS, control.addonFolderIcon(control.lang(50203)))
            
        self.endDirectory()

        # from resources.lib.libraries import cache
        # from resources.lib.libraries import changelog
        # cache.get(changelog.get, 600000000, control.addonInfo('version'), table='changelog')
            
    def showMyList(self):   
        categories = tfctv.getMyListCategories()
        for c in categories:
            self.addDirectoryItem(c['name'], str(c['id']), config.LISTCATEGORY, control.addonFolderIcon(c['name']), **self.formatMenu())
        self.endDirectory()

    def showMyListCategory(self, url):   
        items = tfctv.getMylistCategoryItems(url)
        for e in items:
            if e['type'] == 'show':
                image = e['logo'] if control.setting('useShowLogo') == 'true' else e['image']
                self.addDirectoryItem(e['name'], str(e['id']), config.SHOWEPISODES, image, isFolder=True, **self.formatShowInfo(e, addToList=False))
            elif e['type'] == 'episode':
                self.addDirectoryItem(e['title'], str(e['id']), config.PLAY, e['image'], isFolder = False, **self.formatVideoInfo(e, addToList=False))
        self.endDirectory()
            
    def showCategories(self):   
        # categories = cache.lCacheFunction(tfctv.getCategories)
        categories = tfctv.getCategories()
        for c in categories:
            self.addDirectoryItem(c['name'], str(c['id']), config.SUBCATEGORIES, control.addonFolderIcon(c['name']), isFolder=True, **self.formatMenu())
            
        if control.setting('displayWebsiteSections') == 'true':
            self.endDirectory()
          
    def showSubCategories(self, categoryId):
        # subCategories = cache.lCacheFunction(tfctv.getSubCategories, categoryId)
        subCategories = tfctv.getSubCategories(categoryId)
        for s in subCategories:
            self.addDirectoryItem(s['name'], str(s['id']), config.SUBCATEGORYSHOWS, control.addonFolderIcon(s['name']), isFolder=True, **self.formatMenu())
        self.endDirectory()
       
    def showSubCategoryShows(self, subCategoryId):
        # shows = cache.sCacheFunction(tfctv.getShows, subCategoryId)
        shows = tfctv.getShows(subCategoryId)
        if len(shows) > 0:
            self.displayShows(shows)
        else:
            self.endDirectory()
        
    def showWebsiteSectionContent(self, section, page=1):
        itemsPerPage = int(control.setting('itemsPerPage'))
        content = tfctv.getWebsiteSectionContent(section, page, itemsPerPage)
        for e in content:
            if e['type'] == 'show':
                image = e['logo'] if control.setting('useShowLogo') == 'true' else e['image']
                self.addDirectoryItem(e['name'], str(e['id']), config.SHOWEPISODES, image, isFolder=True, **self.formatShowInfo(e))
            elif e['type'] == 'episode':
                self.addDirectoryItem(e['title'], str(e['id']), config.PLAY, e['image'], isFolder = False, **self.formatVideoInfo(e))
        if len(content) == itemsPerPage:
            self.addDirectoryItem("Next >>", section, config.SECTIONCONTENT, '', page + 1)
        self.endDirectory()

    def displayShows(self, shows):
        sortedShowInfos = []
        for show in shows:
            image = show['logo'] if control.setting('useShowLogo') == 'true' else show['image']
            sortedShowInfos.append((show['name'].lower(), show['name'], str(show['id']), config.SHOWEPISODES, image, self.formatShowInfo(show)))
        
        sortedShowInfos = sorted(sortedShowInfos, key = itemgetter(0))
        for info in sortedShowInfos:
            self.addDirectoryItem(info[1], info[2], info[3], info[4], isFolder=True, **info[5])
                
        self.endDirectory()
        
    def showEpisodes(self, showId, page=1):
        itemsPerPage = int(control.setting('itemsPerPage'))
        # episodes = cache.sCacheFunction(tfctv.getEpisodesPerPage, showId, page, itemsPerPage)
        episodes = tfctv.getEpisodesPerPage(showId, page, itemsPerPage)
        for e in episodes:
            self.addDirectoryItem(e['title'], str(e['id']), config.PLAY, e['image'], isFolder = False, **self.formatVideoInfo(e))
        if len(episodes) == itemsPerPage:
            self.addDirectoryItem("Next >>", showId, config.SHOWEPISODES, '', page + 1)
        self.endDirectory()
            
    def showMyAccount(self):
        tfctv.checkAccountChange(False)
        categories = [
            { 'name' : 'My info', 'url' : '/profile', 'mode' : config.MYINFO },
            { 'name' : 'My subscription', 'url' : '/', 'mode' : config.MYSUBSCRIPTIONS },
            { 'name' : 'Transactions', 'url' : '/', 'mode' : config.MYTRANSACTIONS }
        ]
        for c in categories:
            self.addDirectoryItem(c['name'], c['url'], c['mode'], control.addonFolderIcon(c['name']))
        self.addDirectoryItem('Logout', '/', config.LOGOUT, control.addonFolderIcon('Logout'), isFolder = False)    
        self.endDirectory()
    
    def showMyInfo(self):
        loggedIn = tfctv.isLoggedIn()
        message = control.lang(57002)
        if loggedIn == True:
            try:
                user = tfctv.getUserInfo()
                message = 'First name: %s\nLast name: %s\nEmail: %s\nState: %s\nCountry: %s\nMember since: %s\n\n' % (
                    user.get('firstName', ''),
                    user.get('lastName', ''), 
                    user.get('email', ''), 
                    user.get('state', ''),
                    user.get('country', ''), 
                    user.get('memberSince', '')
                    )
            except:
                pass
        control.showMessage(message, control.lang(56001))
    
    def showMySubscription(self):
        sub = tfctv.getUserSubscription()
        message = ''
        if sub:
            message += '%s' % (sub['Details'])
        else:
            message = control.lang(57002)
        control.showMessage(message, control.lang(56002))
        
    def showMyTransactions(self):
        transactions = tfctv.getUserTransactions()
        message = ''
        if len(transactions) > 0:
            for t in transactions:
                message += t + "\n"
        else:
            message = control.lang(57002)
        control.showMessage(message, control.lang(56003))
            
    def showTools(self):
        self.addDirectoryItem('Reload Catalog Cache', '/', config.RELOADLIBRARY, control.addonFolderIcon('Reload Catalog Cache'))
        self.addDirectoryItem('Clean cookies file', '/', config.CLEANCOOKIES, control.addonFolderIcon('Clean cookies file'))
        self.endDirectory()
            
    def formatMenu(self, bgImage=''):
        if bgImage == '': bgImage = control.setting('defaultBG')
        data = { 
            'listArts' : { 'fanart' : bgImage, 'banner' : bgImage }
            }
        return data
        
    def formatShowInfo(self, info, addToList=True, options = {}):
        add = { control.lang(50300) : 'XBMC.Container.Update(%s)' % self.generateActionUrl(str(info['id']), config.ADDTOLIST, info['name'], query='type=show') } 
        remove = { control.lang(50301) : 'XBMC.Container.Update(%s)' % self.generateActionUrl(str(info['id']), config.REMOVEFROMLIST, info['name'], query='type=show') } 
        contextMenu = add if addToList == True else remove
        
        data = { 
            'listArts' : { 'fanart' : info['fanart'], 'banner' : info['fanart'] }, 
            'listInfos' : { 
                'video' : { 'plot' : info['description'], 'year' : info['year'] } 
                },
            'contextMenu' : contextMenu
            }
        return data
            
    def formatVideoInfo(self, info, addToList=True, options = {}):
        add = { control.lang(50300) : 'XBMC.Container.Update(%s)' % self.generateActionUrl(str(info['id']), config.ADDTOLIST, info['title'], query='type=episode') } 
        remove = { control.lang(50301) : 'XBMC.Container.Update(%s)' % self.generateActionUrl(str(info['id']), config.REMOVEFROMLIST, info['title'], query='type=episode') } 
        contextMenu = add if addToList == True else remove

        data = { 
            'listArts' : { 'fanart' : info['fanart'], 'banner' : info['fanart'] }, 
            'listProperties' : { 'IsPlayable' : 'true' } , 
            'listInfos' : { 
                'video' : { 
                    'tvshowtitle' : info['show'], 
                    'episode' : info['episodenumber'], 
                    'tracknumber' : info['episodenumber'], 
                    'plot' : info['description'], 
                    'aired' : info['dateaired'], 
                    'year' : info['year'] 
                    } 
                },
            'contextMenu' : contextMenu
            }
        return data
            
            
    # def addDirectoryItem(self, name, query, thumb, icon, context=None, isAction=True, isFolder=True):
        # try: name = control.lang(name).encode('utf-8')
        # except: pass
        # url = '%s?action=%s' % (sysaddon, query) if isAction == True else query
        # thumb = os.path.join(artPath, thumb) if not artPath == None else icon
        # cm = []
        # if not context == None: cm.append((control.lang(context[0]).encode('utf-8'), 'RunPlugin(%s?action=%s)' % (sysaddon, context[1])))
        # item = control.item(label=name, iconImage=thumb, thumbnailImage=thumb)
        # item.addContextMenuItems(cm, replaceItems=False)
        # if not addonFanart == None: item.setProperty('Fanart_Image', addonFanart)
        # control.addItem(handle=int(sys.argv[1]), url=url, listitem=item, isFolder=isFolder)
            
    def addDirectoryItem(self, name, url, mode, thumbnail, page=1, isFolder=True, query='', **kwargs):
        u = self.generateActionUrl(url, mode, name, thumbnail, page, query)
        liz = control.item(label=name, iconImage="DefaultFolder.png", thumbnailImage=thumbnail)
        liz.setInfo(type="Video", infoLabels={"Title": name})
        for k, v in kwargs.iteritems():
            if k == 'listProperties':
                for listPropertyKey, listPropertyValue in v.iteritems():
                    liz.setProperty(listPropertyKey, listPropertyValue)
            if k == 'listInfos':
                for listInfoKey, listInfoValue in v.iteritems():
                    liz.setInfo(listInfoKey, listInfoValue)
            if k == 'listArts':
                liz.setArt(v)
            if k == 'contextMenu':
                menuItems = []
                for label, action in v.iteritems():
                    menuItems.append((label, action))
                if len(menuItems) > 0: liz.addContextMenuItems(menuItems)
        return control.addItem(handle=thisPlugin, url=u, listitem=liz, isFolder=isFolder)

    def generateActionUrl(self, url, mode, name=None, thumbnail='', page=1, query=''):
        url = sysaddon + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode)
        try: 
            if name != None: url += "&name=" + urllib.quote_plus(name)
        except: 
            pass
        try: 
            if int(page) >= 0: url += "&page=" + str(page)
        except: 
            pass
        try: 
            if thumbnail != '': url += "&thumbnail=" + urllib.quote_plus(thumbnail)
        except: 
            pass    
        try: 
            if query != '': url += "&" + query
        except: 
            pass
        return url   

    def endDirectory(self, cacheToDisc=True):
        control.directory(int(sys.argv[1]), cacheToDisc=cacheToDisc)


